package bts.sio.azurimmo.model

data class Intervenant (
    val id: Int,
    val nom: String,
)